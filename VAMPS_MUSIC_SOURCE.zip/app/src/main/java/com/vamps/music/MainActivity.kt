package com.vamps.music

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

private val AppBackground = Color(0xFF090A0F)
private val MutedText = Color(0xFF9BA1B1)
private val Violet = Color(0xFFB8A4FF)

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                try {
                    mediaController = future.get()
                } catch (_: Exception) {
                    mediaController = null
                }
            },
            mainExecutor
        )

        setContent {
            VampsApp(
                controllerProvider = { mediaController },
                onPlayUri = { uri, title ->
                    mediaController?.let { controller ->
                        val item = MediaItem.Builder()
                            .setUri(uri)
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(title)
                                    .build()
                            )
                            .build()
                        controller.setMediaItem(item)
                        controller.prepare()
                        controller.play()
                    }
                }
            )
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        mediaController = null
        super.onDestroy()
    }
}

private data class LocalTrack(val uri: Uri, val title: String)

@Composable
private fun VampsApp(
    controllerProvider: () -> MediaController?,
    onPlayUri: (Uri, String) -> Unit
) {
    var selectedTab by remember { mutableStateOf("Home") }
    var currentTitle by remember { mutableStateOf("Nothing playing") }
    var isPlaying by remember { mutableStateOf(false) }
    var tracks by remember { mutableStateOf(emptyList<LocalTrack>()) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }

    val context = androidx.compose.ui.platform.LocalContext.current

    val musicPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val imported = uris.mapIndexed { index, uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some document providers do not grant persistable access.
            } catch (_: UnsupportedOperationException) {
                // Playback can still work during this app session.
            }

            val rawName = uri.lastPathSegment
                ?.substringAfterLast('/')
                ?.substringBeforeLast('.')
                ?.takeIf { it.isNotBlank() }

            LocalTrack(uri, rawName ?: "Local track ${index + 1}")
        }
        tracks = (tracks + imported).distinctBy { it.uri }
        if (tracks.isNotEmpty()) selectedTab = "Library"
    }

    // Polling keeps the mini-player responsive even if the controller connects
    // shortly after the first composition.
    LaunchedEffect(Unit) {
        while (isActive) {
            controllerProvider()?.let { controller ->
                positionMs = controller.currentPosition.coerceAtLeast(0L)
                durationMs = controller.duration.takeIf { it > 0L } ?: 0L
                isPlaying = controller.isPlaying
                controller.currentMediaItem?.mediaMetadata?.title?.toString()?.let {
                    currentTitle = it
                }
            }
            delay(400)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            background = AppBackground,
            surface = Color(0xFF171A23),
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF1B1B2A), AppBackground, Color(0xFF10121A))
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp)
            ) {
                Header()

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Home", "Library", "Sources").forEach { tab ->
                        val active = selectedTab == tab
                        Surface(
                            color = if (active) Color.White.copy(alpha = 0.16f)
                            else Color.White.copy(alpha = 0.055f),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.clickable { selectedTab = tab }
                        ) {
                            Text(
                                tab,
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                                color = if (active) Color.White else MutedText,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))

                when (selectedTab) {
                    "Library" -> LibraryScreen(
                        tracks = tracks,
                        onAddMusic = { musicPicker.launch(arrayOf("audio/*")) },
                        onPlay = { track ->
                            currentTitle = track.title
                            onPlayUri(track.uri, track.title)
                        }
                    )

                    "Sources" -> SourcesScreen(localTrackCount = tracks.size)

                    else -> HomeScreen(
                        onImport = { musicPicker.launch(arrayOf("audio/*")) },
                        onLibrary = { selectedTab = "Library" }
                    )
                }

                Spacer(Modifier.weight(1f, fill = false))

                MiniPlayer(
                    title = currentTitle,
                    isPlaying = isPlaying,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    onToggle = {
                        controllerProvider()?.let { controller ->
                            if (controller.isPlaying) controller.pause() else controller.play()
                        }
                    },
                    onSeek = { fraction ->
                        val duration = durationMs
                        if (duration > 0L) {
                            controllerProvider()?.seekTo((fraction * duration).toLong())
                        }
                    }
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp, bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    listOf(
                        "Home" to Icons.Rounded.Home,
                        "Library" to Icons.Rounded.LibraryMusic,
                        "Sources" to Icons.Rounded.Hub
                    ).forEach { (label, icon) ->
                        IconButton(onClick = { selectedTab = label }) {
                            Icon(
                                icon,
                                contentDescription = label,
                                tint = if (selectedTab == label) Violet else MutedText
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 22.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                "VAMPS",
                fontSize = 12.sp,
                color = Violet,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp
            )
            Text(
                "MUSIC",
                fontSize = 27.sp,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )
        }
        Surface(
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.08f),
            modifier = Modifier.size(44.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Search, contentDescription = "Search", tint = Color.White)
            }
        }
    }
}

@Composable
private fun HomeScreen(onImport: () -> Unit, onLibrary: () -> Unit) {
    Column {
        Text("Good music. No noise.", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(
            "Your sound, in one place.",
            color = MutedText,
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 5.dp)
        )
        Spacer(Modifier.height(22.dp))

        GlassCard(Modifier.fillMaxWidth().height(184.dp)) {
            Column(
                modifier = Modifier.fillMaxSize().padding(18.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "YOUR LIBRARY",
                    color = Violet,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Column {
                    Text("Bring your music", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Import audio files from your phone.",
                        color = MutedText,
                        fontSize = 12.sp
                    )
                }
                Button(
                    onClick = onImport,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = AppBackground
                    )
                ) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Import music")
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(
            "QUICK ACCESS",
            color = MutedText,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickTile(
                "Local files",
                Icons.Rounded.Folder,
                Modifier.weight(1f),
                onLibrary
            )
            QuickTile(
                "Lyrics",
                Icons.Rounded.MusicNote,
                Modifier.weight(1f),
                onLibrary
            )
        }
    }
}

@Composable
private fun LibraryScreen(
    tracks: List<LocalTrack>,
    onAddMusic: () -> Unit,
    onPlay: (LocalTrack) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Your library", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        TextButton(onClick = onAddMusic) {
            Icon(Icons.Rounded.Add, contentDescription = null)
            Text("Add music")
        }
    }

    if (tracks.isEmpty()) {
        EmptyState(
            title = "Your music lives here",
            subtitle = "Choose audio files from your phone to start listening.",
            button = "Choose music",
            onClick = onAddMusic
        )
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tracks, key = { it.uri.toString() }) { track ->
                TrackRow(track.title) { onPlay(track) }
            }
        }
    }
}

@Composable
private fun SourcesScreen(localTrackCount: Int) {
    Text("Music sources", fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    SourceRow("YouTube Music", "Official APIs / supported app handoff", "Not connected")
    SourceRow("Spotify", "Official SDK / user-authorized remote playback", "Not connected")
    SourceRow("SoundCloud", "Subject to API access and provider approval", "Not connected")
    SourceRow(
        "Local music",
        "Audio files selected from this device",
        if (localTrackCount == 0) "Ready" else "$localTrackCount imported"
    )
    Text(
        "Online providers need approved developer access and may require their own apps or subscriptions. VAMPS does not bypass provider ads, subscriptions or playback restrictions.",
        color = MutedText,
        fontSize = 12.sp,
        lineHeight = 18.sp,
        modifier = Modifier.padding(top = 16.dp)
    )
}

@Composable
private fun MiniPlayer(
    title: String,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onToggle: () -> Unit,
    onSeek: (Float) -> Unit
) {
    GlassCard(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(listOf(Violet, Color(0xFF484A70)))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = Color.White)
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp)
                ) {
                    Text(
                        title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Text(
                        "VAMPS MUSIC",
                        color = MutedText,
                        fontSize = 10.sp,
                        letterSpacing = 1.sp
                    )
                }
                IconButton(onClick = onToggle) {
                    Icon(
                        if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            if (durationMs > 0L) {
                Slider(
                    value = (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f),
                    onValueChange = onSeek,
                    modifier = Modifier.height(26.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = Violet,
                        activeTrackColor = Violet,
                        inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                    )
                )
            }
        }
    }
}

@Composable
private fun GlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        color = Color.White.copy(alpha = 0.075f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
    ) {
        Column(content = content)
    }
}

@Composable
private fun EmptyState(
    title: String,
    subtitle: String,
    button: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 56.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Rounded.LibraryMusic,
            contentDescription = null,
            tint = Violet,
            modifier = Modifier.size(48.dp)
        )
        Spacer(Modifier.height(14.dp))
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MutedText, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick = onClick) { Text(button) }
    }
}

@Composable
private fun TrackRow(title: String, onClick: () -> Unit) {
    Surface(
        color = Color.White.copy(alpha = 0.055f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Violet)
            Text(
                title,
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 13.sp
            )
            Icon(Icons.Rounded.PlayCircle, contentDescription = "Play", tint = Color.White)
        }
    }
}

@Composable
private fun SourceRow(name: String, description: String, status: String) {
    Surface(
        color = Color.White.copy(alpha = 0.055f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Headphones, contentDescription = null, tint = Violet)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Text(name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(description, color = MutedText, fontSize = 11.sp)
            }
            Text(status, color = MutedText, fontSize = 10.sp)
        }
    }
}

@Composable
private fun QuickTile(
    label: String,
    icon: ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.height(88.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.07f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.10f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(icon, contentDescription = null, tint = Violet)
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
