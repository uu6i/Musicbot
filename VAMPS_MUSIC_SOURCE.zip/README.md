# VAMPS MUSIC — v0.2.0 Android starter

This is a native Android Kotlin + Jetpack Compose project. It is not a website or WebView wrapper.

## Important build compatibility fix

The previous archive used Android Gradle Plugin 8.13.2 and Kotlin 2.3.21 while Code On The Go selected Gradle 9.6.1. That combination caused a Gradle internal API incompatibility.

This archive uses a deliberately matched toolchain:

| Component | Version |
|---|---:|
| Android Gradle Plugin | 8.11.1 |
| Kotlin + Compose compiler plugin | 2.2.20 |
| Gradle wrapper | 8.13 |
| JDK | 17 |
| Compile SDK | 36 |
| Compose BOM | 2026.04.01 |
| AndroidX Media3 | 1.11.1 |

AGP 8.11.x requires Gradle 8.13. The wrapper properties are included.

## If Code On The Go still runs Gradle 9.6.1

Some mobile IDE builds use their own configured Gradle distribution and ignore the project wrapper. In Code On The Go, open the project/build settings and select **Gradle 8.13** (not 9.6.1), then sync again. If the app only offers a fixed Gradle 9.6.1 and cannot use the wrapper or change the distribution, this project cannot use AGP 8.11.1 there; use an IDE that supports the project wrapper or a compatible Gradle 8.13 install.

Use JDK 17 if the IDE exposes a JDK setting.

## Build

1. Extract the ZIP into a normal writable folder.
2. Open the extracted `VAMPS_MUSIC_v0_2` folder as a Gradle project.
3. Let Gradle sync and download dependencies.
4. Build the `app` debug variant (or run `:app:assembleDebug`).
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Included in this starter

- Jetpack Compose dark Liquid-Glass-inspired UI
- Home, Library and Sources screens
- Android document picker for selecting multiple local audio files
- Media3 ExoPlayer playback
- MediaSessionService for background media playback
- Mini-player with play/pause and seek
- Provider integration placeholders

## Provider limitations

The YouTube Music, Spotify and SoundCloud rows are intentionally marked as not connected. Each provider requires its own approved developer access, user authorization, and supported playback model. This project does not extract streams, bypass ads, or circumvent subscriptions. Local audio playback is implemented independently.

## Troubleshooting

- `InternalProblems ... removed in Gradle 9.6`: ensure Gradle 8.13 is selected.
- `Android SDK location not found`: configure the Android SDK path in the IDE.
- `SDK platform 36 not found`: install Android SDK Platform 36 using the IDE's SDK manager.
- `Unsupported class file major version` or Java toolchain errors: select JDK 17.
- `Could not resolve ...`: check internet access and allow Google Maven + Maven Central.
- If Kotlin reports an unresolved import or Compose error, send the complete first compiler error, not only the final `BUILD FAILED` line.

## Build status

This source archive has been reviewed and updated for the reported Gradle mismatch, but it has not been compiled on your specific phone/Code On The Go installation. No APK is included yet.
